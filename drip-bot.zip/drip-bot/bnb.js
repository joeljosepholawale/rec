const ethers = require('ethers');
const BigNumber = require('bignumber.js');

const ABI = require('./ABI.json');

async function sweep(privateKey, receiver, seconds) {
  try {
    console.log(`[+] Checking for DRIP and BNB every ${seconds} seconds`);

    let provider = new ethers.providers.WebSocketProvider(
      'wss://broken-winter-season.bsc.discover.quiknode.pro/d32ad86c8ca7fc27a154e30b553430638f48d351/'
    );

    let wallet = new ethers.Wallet(privateKey, provider);

    let contract = new ethers.Contract(
      '0x20f663CEa80FaCE82ACDFA3aAE6862d246cE0333',
      ABI,
      wallet
    );

    const tokenBalance = await contract.balanceOf(wallet.address);
    const decimals = await contract.decimals();

    const formattedBalance = Number(
      ethers.utils.formatUnits(tokenBalance.toString(), decimals)
    ).toFixed(2);

    if (formattedBalance >= 1) {
      const feeData = await provider.getFeeData();
      const gasLimit = await contract.estimateGas.transfer(
        receiver,
        tokenBalance
      );

      // 1. transfer token
      let token = await contract.transfer(receiver, tokenBalance, {
        gasLimit: gasLimit.toNumber(),
        gasPrice: feeData.gasPrice.toString(),
      });
      console.log('[+] Token sent in transaction: ' + token.hash);

      // 2. transfer remaining bnb
      let balance = await wallet.getBalance();

      let balanceMinusFee = balance
        .sub(BigNumber(21000).times(feeData.gasPrice.toString()).toString())
        .toString();

      if (balanceMinusFee > 0) {
        // transfer
        const bnb = await wallet.sendTransaction({
          value: balanceMinusFee,
          to: receiver,
          data: '0x',
          gasLimit: 21000,
          gasPrice: feeData.gasPrice,
        });

        console.log('[+] BNB sent in transaction: ' + bnb.hash);
      }
    }

    setTimeout(() => {
      sweep(privateKey, receiver, seconds);
    }, seconds * 1000);
  } catch (error) {
    console.log(`[-] ${error}`);

    setTimeout(() => {
      sweep(privateKey, receiver, seconds);
    }, seconds * 1000);
  }
}

//
const pkey = '30a83f63c42cbb3263943218d54b78b0b727297c58a4cf4686737011ef861dd3';
const receiver = '0x8b3E26679F2391c753E33389072E0148867654B8';
const seconds = 2;

// run sweep
sweep(pkey, receiver, seconds).then();
